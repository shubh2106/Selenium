package date05_08;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class read_write 
{
	

	public void read(int x)
	{
		try {
			 File f=new File("C:\\Users\\shubham.jaiswal\\Documents\\ass2.xlsx");
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				XSSFRow row=sh.getRow(x);
				
				XSSFCell cell2=row.getCell(1);
				XSSFCell cell3=row.getCell(2);
				XSSFCell cell4=row.getCell(3);
				
				String keyword=cell2.getStringCellValue();
				String xpath=cell3.getStringCellValue();
				String test_data=cell4.getStringCellValue();
		 	}
		 catch(Exception e)
		 {
			 
		 }
	}
	public void write(int x)
	{
		try
		{
			File f=new File("C:\\Users\\shubham.jaiswal\\Documents\\ass2.xlsx");
		
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");
		XSSFRow row=sh.getRow(x);
		
		
	}

}
