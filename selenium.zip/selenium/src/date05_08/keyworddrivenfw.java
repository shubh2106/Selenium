package date05_08;

public class keyworddrivenfw 
{
String kw,xp,td;
}
