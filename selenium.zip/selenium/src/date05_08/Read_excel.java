package Day7;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Read_excel extends Web_Elements{
	public static ArrayList<Web_Elements> read_excel()
	{
		ArrayList<Web_Elements> al = new ArrayList<Web_Elements>();
		try {
			File f = new File("C:\\Users\\sajal.gupta1\\workspace\\TESTNG_Project\\src\\Day7\\List.xlsx");
			FileInputStream fin = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fin);
			XSSFSheet s = wb.getSheet("sheet1");
				for(int j=1;j<7;j++)
				{
				Web_Elements s1 = new Web_Elements();
				XSSFRow r =    s.getRow(j);
				XSSFCell c =   r.getCell(1);
				XSSFCell c1 =  r.getCell(2);
				XSSFCell c2 =  r.getCell(3);
				try {
				s1.key=    c.getStringCellValue();
				s1.xp	=	   c1.getStringCellValue();
				s1.test_data=  c2.getStringCellValue();
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				al.add(s1);
				}
				
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return al;
	}
	
	public static void write_excel(ArrayList<Web_Elements> al)
	{
		File f = new File("C:\\Users\\sajal.gupta1\\workspace\\TESTNG_Project\\src\\Day7\\List.xlsx");
		FileInputStream fin;
		try {
			fin = new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fin);
			XSSFSheet s = wb .getSheet("sheet1");
			XSSFRow r = s.getRow(6);
			XSSFCell c = r.createCell(4);
			c.setCellValue(al.get(5).result);
			FileOutputStream fout = new FileOutputStream(f);
			wb.write(fout);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	

}
