package Day7;

public class Web_Elements {
	String key,xp;
	String test_data,result;
}
