package Day7;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class All_Web_Elements {
	WebDriver wb;
	public void launch_browser(String url)
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		wb = new ChromeDriver();
		wb.get(url);
	}
	
	
	public void click(String xp)
	{
		wb.findElement(By.xpath(xp)).click();
	}
	
	public void enter_text(String xp , String data) {
		wb.findElement(By.xpath(xp)).sendKeys(data);
	}
	
	public void verify(String xp , String exp_result, ArrayList<Web_Elements> al) {
		String act_reult = wb.findElement(By.xpath(xp)).getText();
		if(act_reult.compareToIgnoreCase(exp_result)==0)
		{
			al.get(5).result="Pass";
		}
		else
		{
			al.get(5).result="Fail";
		}
	}
}
