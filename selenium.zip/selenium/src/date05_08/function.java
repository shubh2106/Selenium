package date05_08;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class function 
{
	String xp;
	String keywrd;
	String text_data;
	boolean text_res;
	public WebDriver browser(String url)
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get(url);
		return dr;
	}
	
	public void enter_text(String xp,String text_data,WebDriver dr)
	{
		dr.findElement(By.xpath(xp)).sendKeys(text_data);
	}
	
	public void click(String xp,WebDriver dr)
	{
		dr.findElement(By.xpath(xp)).click();
	}
	public boolean verify(String text_data,String ar,WebDriver dr)
	{
		String s=dr.findElement(By.xpath(xp)).getText();
		if(s.equals(ar))
			return true;
		else
			return false;
		
		
	}
}
