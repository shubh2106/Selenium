package examination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class ques1 
{
	@BeforeMethod
	public void bm()
	{
		try {
			System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
			WebDriver dr=new ChromeDriver();
			dr.get("http://demowebshop.tricentis.com/");
			dr.findElement(By.className("ico-login")).click();
			
		}
		catch(Exception e) {}
	}
	@Test
	public void f()
	{
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		dr.findElement(By.className("ico-login")).click();
		dr.findElement(By.id("Email")).sendKeys("s.gmail.com");
		dr.findElement(By.id("Password")).sendKeys("shubham");
		dr.findElement(By.xpath("//input[@value='Log in']")).click();
	}
	@Test
	public void f1()
	{
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		dr.findElement(By.className("ico-login")).click();
		dr.findElement(By.id("Email")).sendKeys("shubhjais@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("shubham");
		dr.findElement(By.xpath("//input[@value='Log in']")).click();
	}
	@Test
	public void f2()
	{
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		dr.findElement(By.className("ico-login")).click();
		dr.findElement(By.id("Email")).sendKeys("s@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("shubham");
		dr.findElement(By.xpath("//input[@value='Log in']")).click();
	}
	@AfterMethod
	public void f3()
	{
		WebDriver dr=new ChromeDriver();
		dr.close();
	}
	
	

}
