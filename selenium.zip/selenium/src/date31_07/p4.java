package date31_07;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class p4 {
private static XSSFWorkbook wb;

public static void main(String args[]) {
	/*try{
		File f=new File("C:\\Users\\shubham.jaiswal\\Documents\\3.xlsx");
		FileInputStream fis=new FileInputStream(f);
		wb = new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		for(int i=2;i<=3;i++) 
		{
			XSSFRow row=sh.getRow(i);
			XSSFCell cel1=row.getCell(0);
			XSSFCell cel2=row.getCell(1);
			XSSFCell cel3=row.getCell(2);
			dr.findElement(By.className("ico-login")).click();
			dr.findElement(By.id("Email")).sendKeys(cel1.getStringCellValue());
			dr.findElement(By.id("Password")).sendKeys(cel2.getStringCellValue());
			dr.findElement(By.xpath("//input[@value='Log in']")).click();
			FileOutputStream fos=new FileOutputStream(f);
			XSSFCell cell1=row.createCell(3);
			XSSFCell cell2=row.createCell(4);
			//String b=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span/span")).getText();
			String a=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
			System.out.println(a);
			//System.out.println(b);
			if((cel3.getStringCellValue().equals(a)) ) 
			{
			 cell2.setCellValue("pass");
			 cell1.setCellValue(a);
			}
			//if((cel3.getStringCellValue().equals(b)) )
			//{
			//	cell2.setCellValue("pass");
			//	 cell1.setCellValue(b);
			//}
			else 
			{
				  cell2.setCellValue("fail");
				  cell1.setCellValue(a);
			}
			      wb.write(fos);
			      //wb.close();
			      dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[1]/a/img")).click();
			      dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();   
			}
		dr.close();	
		}
      catch(Exception e) {}
*/}
	public String f2()
	{
		String b="";
		try{
			File f=new File("C:\\Users\\shubham.jaiswal\\Documents\\3.xlsx");
			FileInputStream fis=new FileInputStream(f);
			wb = new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
			WebDriver dr=new ChromeDriver();
			dr.get("http://demowebshop.tricentis.com/");
			
			for(int i=2;i<=2;i++) 
			{
				XSSFRow row=sh.getRow(i);
				XSSFCell cel1=row.getCell(0);
				XSSFCell cel2=row.getCell(1);
				XSSFCell cel3=row.getCell(2);
				dr.findElement(By.className("ico-login")).click();
				dr.findElement(By.id("Email")).sendKeys(cel1.getStringCellValue());
				dr.findElement(By.id("Password")).sendKeys(cel2.getStringCellValue());
				dr.findElement(By.xpath("//input[@value='Log in']")).click();
				FileOutputStream fos=new FileOutputStream(f);
				XSSFCell cell1=row.createCell(3);
				XSSFCell cell2=row.createCell(4);
				b=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
				//return a;
			}
		}
		catch(Exception e)
		{
		}
		return b;	
	}
}
