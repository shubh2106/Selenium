package date06_08;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class pro2 
{
	Logger log;
	  @Test
	  public void f() 
	  {
		  
		  String er="NOIDA",ar="NOIDA";
		  System.out.println("in test1");
		  Assert.assertEquals(ar,er);
		  System.out.println("in test1 - after assert");
		  log= Logger.getLogger("devpinoyLogger");
		  log.info("Test 1 executed");
	  }
	  @Test
	  public void test2()
	  {
		  String er="NOIDA",ar="NOID";
		  System.out.println("in test2");
		  SoftAssert sa= new SoftAssert();
		  sa.assertAll();
		  System.out.println("in test2- after assert");
//		  sa.assertAll();
		  log= Logger.getLogger("devpinoyLogger");
		  log.info("Test 2 executed");
	  }
}

