package date30_07;

	

	import java.io.File;
	import java.io.FileInputStream;
	import java.io.FileOutputStream;
	import java.io.IOException;
	import java.io.OutputStream;

	import java.io.File;
	import java.io.FileInputStream;

	import org.apache.poi.xssf.usermodel.XSSFCell;
	import org.apache.poi.xssf.usermodel.XSSFRow;
	import org.apache.poi.xssf.usermodel.XSSFSheet;
	import org.apache.poi.xssf.usermodel.XSSFWorkbook;
	import org.apache.poi.xssf.usermodel.XSSFSheet;
	import org.apache.poi.xssf.usermodel.XSSFWorkbook;

	public class childexcercise4 
	{
		 public static excercise4 read_exl(int x)
		 {
			 excercise4 s1=new excercise4();
			 try {
				 File f=new File("C:\\Users\\shubham.jaiswal\\Desktop\\1.xlsx");
					FileInputStream fis=new FileInputStream(f);
					XSSFWorkbook wb=new XSSFWorkbook(fis);
					XSSFSheet sh=wb.getSheet("Sheet1");
					XSSFRow row=sh.getRow(x);
					XSSFCell cell1=row.getCell(0);
					XSSFCell cell2=row.getCell(1);
					XSSFCell cell3=row.getCell(2);
					
					s1.gmail=cell1.getStringCellValue();
					s1.pass=cell2.getStringCellValue();
					s1.expecgmail=cell3.getStringCellValue();
					
					wb.close();
			 	}
			 catch(Exception e)
			 {
			 }
		 
			return s1;
		 }
		 public static void write_exl(int x,String grade)
		 {
			 
			 try
			 {
				 File f=new File("C:\\Users\\shubham.jaiswal\\Desktop\\1.xlsx");
			 
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				XSSFRow row=sh.getRow(x);
			
			 FileOutputStream fos=new FileOutputStream(f);
				XSSFCell cell=row.getCell(3);
				cell.setCellValue(grade);
				
				wb.write(fos);
				wb.close();
				
				
			 }
			 catch(Exception e)
			 {
				 
			 }
		 }
	}


