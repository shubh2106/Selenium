package date30_07;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class p1 
{

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		/*dr.get("https://www.facebook.com");
		List rb=dr.findElements(By.name("sex"));
		((WebElement)rb.get(1)).click();
		*/
		dr.get("http://demo.guru99.com/test/radio.html");
		WebElement option1 = dr.findElement(By.id("vfb-6-1"));
					

        // Check whether the Check box is toggled on 		
        if (option1.isSelected()) {					
            System.out.println("Checkbox is Toggled On");					

        } else {
        	option1.click();
            System.out.println("Checkbox is Toggled Off");					
        }
	}

}
