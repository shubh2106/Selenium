package date30_07;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class excercise6 
{
	public static void main(String args[])
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		//String s=dr.getTitle();
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[1]/td/select")).click();
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[3]/td/input")).click();
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[1]/td[2]/b/a")).click();
		String a1=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/h1")).getText();
		String a2=(dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/table/tbody/tr/td[2]")).getText()).substring(8);
		double a3=Double.parseDouble(a2);
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[1]/input")).clear();
	    dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[1]/input")).sendKeys("2");
	    dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[2]/input[1]")).click();
	    dr.findElement(By.xpath("/html/body/table[2]/tbody/tr/td/a[1]")).click();
		        
		   

		        
		        dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[1]/td/select/option[4]")).click();
		        dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[3]/td/input")).click();
		        dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[1]/td[2]/b/a")).click();
		        String b1=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/h1")).getText();
		        
		        String b2=(dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/table/tbody/tr/td[2]")).getText()).substring(8);
		        double b3=Double.parseDouble(b2);
		        dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[1]/input")).clear();
			    dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[1]/input")).sendKeys("3");
		        dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[2]/input[1]")).click();
		        dr.findElement(By.xpath("/html/body/table[2]/tbody/tr/td/a[1]")).click();

		        
		        
		        dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[1]/td/select/option[2]")).click();
		        dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[3]/td/input")).click();
		        dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[1]/td[2]/b/a")).click();
		        String c1=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/h1")).getText();
		        String c2=(dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/table/tbody/tr/td[2]")).getText()).substring(8);
		        double c3=Double.parseDouble(c2);
		        dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[1]/input")).clear();
			    dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[1]/input")).sendKeys("4");
		        dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[2]/input[1]")).click();

		        String a=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[2]/td[1]")).getText();
		        String b=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[3]/td[1]")).getText();
		        String c=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[4]/td[1]")).getText();
		        Double d=Double.parseDouble((dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[2]/td[4]")).getText()).substring(1));
		        Double e=Double.parseDouble((dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[3]/td[4]")).getText()).substring(1));
		        Double f=Double.parseDouble((dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[4]/td[4]")).getText()).substring(1));
		        Double g=Double.parseDouble((dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/p")).getText()).substring(8));
		        //Double q=Double.parseDouble((String.format("%.2f", (d+e+f))));
		        BigDecimal bd = new BigDecimal(d+e+f).setScale(2, RoundingMode.HALF_UP);
		        double newInput = bd.doubleValue();
		        if((a1.trim()).equals(a.trim()) && (b1.trim()).equals(b.trim()) && (c1.trim()).equals(c.trim()))
		        	System.out.println("It matches");
		        else
		        	System.out.println("nothing happeing");
		        if(a3*2==d && b3*3==e && c3*4==f)
		        	System.out.println("yes they are correct");
		        if(newInput==g)
		        	System.out.println("total is also correct");
		        else
		            System.out.println("double : " );

		        
		       
		       // System.out.println(d.substring(1));
		        //System.out.println(e);
		        //System.out.println(newInput);
		        //System.out.println(g);
		       //System.out.println(a1);
		        //System.out.println(a2.substring(8));
		       //System.out.println(b1);
		        //System.out.println(b2);
		       //System.out.println(c1);
		        //System.out.println(c2);
		        dr.close();
		        
		        

	}

}
