package date30_07;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class excercise4 extends childexcercise4
{

			public static String gmail;
			static String pass;
			String expecgmail;
			
			public static void main(String args[])
			{
				
				ArrayList<excercise4> col=new ArrayList<excercise4>();
				
				
				for(int x=1; x<=3;x++)
				{
					excercise4 s2=new excercise4();
					
					s2=read_exl(x);
					System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
					WebDriver dr=new ChromeDriver();
					String cs=gmail;
					dr.get("http://demowebshop.tricentis.com/");
					dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
					dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(gmail);
					dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(pass);
					dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
					String a=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
					if(a.contentEquals(cs))
						write_exl(x,"passed");
					else
						write_exl(x,"fail");
					dr.quit();
					
					
					
				}
				//System.out.println(s2);
				
			}
		}





