package date30_07;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ecercise5 
{
	public static void main(String args[])
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		String expected="Online Bookstore";
		String actualTitle = "";
		actualTitle=dr.getTitle();
		if(expected.contentEquals(actualTitle))
			System.out.println("passed");
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[1]/td/select/option[3]")).click();
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[3]/td/input")).click();
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[1]/td[2]/b/a")).click();
		String a=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/h1")).getText();
		if(a.contentEquals("Web Database Development"))
			System.out.println("yes it's present");
		String bc=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/table/tbody/tr/td[2]")).getText();
		double b=Double.parseDouble(bc.substring(8));
		//System.out.println(b);
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[1]/input")).clear();
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[1]/input")).sendKeys("2");
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[2]/input[1]")).click();
		
		double c=Double.parseDouble((dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[2]/td[4]")).getText()).substring(1));
		double d=b*2;
		if(c==d)
			System.out.println("yes its correct");
		dr.close();
		
		
}
}
