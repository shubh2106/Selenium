package date30_07;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class execercise1 
{
	public static void main(String args[])
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		String expected="Demo Web Shop";
		String actualTitle = "";
		actualTitle=dr.getTitle();
		if(expected.contentEquals(actualTitle))
			System.out.println("passed");
		 dr.findElement(By.className("ico-register")).click();
		 List rb=dr.findElements(By.name("Gender"));
		 ((WebElement)rb.get(1)).click();
		 dr.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys("shubham");
		 dr.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys("jaiswal");
		 dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("shubhajais@gmail.com");
		 dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("shubham");
		 dr.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys("shubham");
		 dr.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
		 dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		 dr.close();
		 

		
	}
}
