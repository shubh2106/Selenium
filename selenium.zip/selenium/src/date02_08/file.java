package date02_08;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

//import JavaAssessment.ques3;

public class file 
{
	public static String read_exl(int x)
	 {
		 //ques3 s1=new ques3();
		 try {
			 File f=new File("C:\\Users\\shubham.jaiswal\\Desktop\\1.xlsx");
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				XSSFRow row=sh.getRow(x);
				XSSFCell cell1=row.getCell(0);
				XSSFCell cell2=row.getCell(1);
				XSSFCell cell3=row.getCell(2);
				XSSFCell cell4=row.getCell(3);
				ques3.sid=(int)cell1.getNumericCellValue();
				ques3.sname=cell2.getStringCellValue();
				ques3.perunit=(int)cell3.getNumericCellValue();
				ques3.unit=(int)cell4.getNumericCellValue();
				wb.close();
				
		 	}
		 catch(Exception e)
		 {
		 }
	 
		return s1;
	 }

}
