package date02_08;

import org.testng.annotations.Test;

public class test_tc1 extends p1
{
	 //p1 p=new p1();
  @Test
  public void f() 
  {
	
	 display();
	 // System.out.println("in tc1");
  }
  
}
