package date02_08;

import org.testng.annotations.Test;

public class test_tc2 
{
	@Test
	public void f1()
	{
		
		
	}
	@Test
	public void f2()
	{
		
	}
}
