package Day4;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class Keyboard_actions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/register");
		
		WebElement we1 = dr.findElement(By.name("FirstName"));
		WebElement we2 = dr.findElement(By.name("LastName"));
		
		Actions act = new Actions(dr);
		Action set1 = act
				.moveToElement(we1)
				.click()
				.sendKeys("Lara")
				.keyDown(we1, Keys.CONTROL)
				.sendKeys("A")
				.sendKeys("c")
				.keyUp(we1, Keys.CONTROL)
				.build();
		set1.perform();
		
		Action set2 = act
				.moveToElement(we2)
				.click()
				.keyDown(we2, Keys.CONTROL)
				.sendKeys("v")
				.keyUp(we2, Keys.CONTROL)
				.build();
		set2.perform();
		
	}

}
